#Im using run as the main of the program
from Game import main

main.run_game()
